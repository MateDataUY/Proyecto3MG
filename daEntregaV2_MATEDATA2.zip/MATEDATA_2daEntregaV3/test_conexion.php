<?php
require_once 'conexcion.php';

try {
    $pdo = Conexion::getPDO();
    echo "Conexión exitosa";
} catch (PDOException $e) {
    echo "Error de conexión: " . $e->getMessage();
}
