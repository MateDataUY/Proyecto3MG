<?php
require_once('../conexcion.php');

header('Content-Type: application/json');

try {
    $pdo = Conexion::getPDO();
    $stmt = $pdo->prepare("
    SELECT 
        ci.id_Comprobante,
        u.Nombre,
        u.Apellido,
        u.Email,
        u.CI,
        t.Telefono,
        ht.HorasRegistradas,
        ht.MotivoFAltante AS Justificacion,
        ci.Observaciones,
        p.ComprobantPago AS ComprobanteURL
    FROM ComprobanteInicial ci
    JOIN Usuario u ON ci.id_Usuario = u.id_Usuario
    JOIN HorasTrabajo ht ON ci.id_Horas = ht.id_Horas
    JOIN PagoMensaul p ON ci.id_Pago = p.id_Pago
    LEFT JOIN TelefonoUsuario t ON u.id_Usuario = t.id_Usuario
    WHERE ci.EStadoAprovacion = 'Pendiente'
    GROUP BY ci.id_Comprobante
");


    $stmt->execute();
    $comprobantes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($comprobantes);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['mensaje' => 'Error al obtener los comprobantes: ' . $e->getMessage()]);
}

?>
