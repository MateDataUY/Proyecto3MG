<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');
require_once '../clases/Admin.php';

$data = json_decode(file_get_contents("php://input"), true);
$admin = new Admin();

if (!isset($data['Nombre']) || !isset($data['Contraseña'])) {
    echo json_encode(['success' => false, 'mensaje' => 'Faltan datos']);
    exit;
}

$resultado = $admin->login($data['Nombre'], $data['Contraseña']);
echo json_encode($resultado);
?>