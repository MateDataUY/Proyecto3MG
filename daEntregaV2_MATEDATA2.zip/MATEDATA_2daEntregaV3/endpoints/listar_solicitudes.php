<?php
require_once __DIR__ . '/../clases/Usuario.php';
require_once __DIR__ . '/../conexcion.php';

$pdo = Conexion::getPDO();

$stmt = $pdo->prepare("SELECT id_Usuario as id, Nombre, Email, Apellido, Direccion, CI, 
    (SELECT telefono FROM Telefonousuario WHERE id_usuario = Usuario.id_Usuario LIMIT 1) as Telefono
    FROM Usuario WHERE Estado = 'Pendiente'");
$stmt->execute();
$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: application/json');
echo json_encode($usuarios);
?>