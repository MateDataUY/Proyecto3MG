<?php
require_once __DIR__ . '/../conexcion.php';

// Recibe JSON POST
$data = json_decode(file_get_contents('php://input'), true);
$id = isset($data['id']) ? $data['id'] : null;
$accion = isset($data['accion']) ? $data['accion'] : null;

if (!$id || !$accion) {
    echo json_encode(['mensaje' => 'Datos incompletos']);
    exit;
}

$pdo = Conexion::getPDO();

if ($accion === 'aceptar') {
    $stmt = $pdo->prepare("UPDATE Usuario SET Estado = 'Activo' WHERE id_Usuario = :id");
    $stmt->execute(['id' => $id]);
    echo json_encode(['mensaje' => 'Usuario aceptado y activado']);
} elseif ($accion === 'rechazar') {
    $stmt = $pdo->prepare("UPDATE Usuario SET Estado = 'Rechazado' WHERE id_Usuario = :id");
    $stmt->execute(['id' => $id]);
    echo json_encode(['mensaje' => 'Usuario rechazado']);
} else {
    echo json_encode(['mensaje' => 'Acción no válida']);
}
?>
