<?php

require_once('../conexcion.php');

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (!isset($data['id_Comprobante'])) {
        http_response_code(400);
        echo json_encode(['mensaje' => 'Error: No se proporcionó el ID del comprobante.']);
        exit;
    }

    $idComprobante = $data['id_Comprobante'];

    try {
        $pdo = Conexion::getPDO();
        $stmt = $pdo->prepare("UPDATE ComprobanteInicial SET EStadoAprovacion = 'Rechazado' WHERE id_Comprobante = ?");
        $stmt->execute([$idComprobante]);

        echo json_encode(['mensaje' => 'Comprobante aceptado con éxito.']);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['mensaje' => 'Error al aceptar el comprobante: ' . $e->getMessage()]);
    }
} else {
    http_response_code(405);
    echo json_encode(['mensaje' => 'Error: Método no permitido.']);
}
?>