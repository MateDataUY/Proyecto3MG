<?php


session_start(); // Iniciar la sesión

require_once('../conexcion.php');

$uploadDir = 'endpoints/uploads/';

if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

if (isset($_FILES['comprobante']) && $_FILES['comprobante']['error'] === UPLOAD_ERR_OK) {
    $nombreArchivo = $_FILES['comprobante']['name'];
    $archivoTemporal = $_FILES['comprobante']['tmp_name'];
    $tamañoArchivo = $_FILES['comprobante']['size'];
    $tipoArchivo = $_FILES['comprobante']['type'];

    $tiposPermitidos = ['application/pdf'];
    if (!in_array($tipoArchivo, $tiposPermitidos)) {
        http_response_code(400);
        echo json_encode(['mensaje' => 'Error: Solo se permiten archivos PDF.']);
        exit;
    }

    $nombreArchivoUnico = uniqid('comprobante_') . '_' . $nombreArchivo;

    $ubicacionFinal = $uploadDir . $nombreArchivoUnico;
    if (move_uploaded_file($archivoTemporal, $ubicacionFinal)) {

        $comentario = isset($_POST['comentario']) ? $_POST['comentario'] : '';

        try {
            $pdo = Conexion::getPDO();

            // Obtener información del usuario (simulado, debes obtenerlo de la sesión o autenticación)
            $usuario_id = 1; // ID del usuario (debes obtenerlo de la sesión)

            // Guardar la información del comprobante en la tabla PagoMensaul
            $stmt = $pdo->prepare("INSERT INTO PagoMensaul (id_Usuario, ComprobantPago) VALUES (?, ?)");
            $stmt->execute([$usuario_id, $ubicacionFinal]);

            $comprobante_id = $pdo->lastInsertId();

            $_SESSION['comprobante_id'] = $comprobante_id; // Guardar el ID en la sesión

            // Actualizar la tabla ComprobanteInicial con el id del pago mensual
            $stmt = $pdo->prepare("INSERT INTO ComprobanteInicial (id_Usuario, Observaciones, Monto) VALUES (?, ?, ?)");
            $stmt->execute([$usuario_id, $comentario, $comprobante_id]); // El monto lo dejo en 0 por ahora, no lo estas enviando

            http_response_code(200);
            echo json_encode(['mensaje' => 'Archivo subido con éxito.', 'ubicacion' => $ubicacionFinal, 'comentario' => $comentario, 'comprobante_id' => $comprobante_id]);
        } catch (PDOException $e) {
            http_response_code(500);
            error_log('Error al guardar en la base de datos: ' . $e->getMessage() . ' - ' . $e->getTraceAsString()); // Registrar el error en el log
            echo json_encode(['mensaje' => 'Error al guardar en la base de datos.']); // No mostrar detalles del error al cliente
        }

    } else {
        http_response_code(500);
        error_log('Error al mover el archivo.'); // Registrar el error en el log
        echo json_encode(['mensaje' => 'Error al mover el archivo.']);
    }
} else {
    http_response_code(400);
    echo json_encode(['mensaje' => 'Error: No se ha enviado ningún archivo o ha habido un error.']);
}
?>