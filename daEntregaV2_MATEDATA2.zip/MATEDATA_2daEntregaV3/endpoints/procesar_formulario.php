<?php
session_start(); 
require_once('../conexcion.php');

// Carpeta física donde se guardan los archivos
$uploadDir = __DIR__ . 'endpoints/uploads/';

// Carpeta accesible públicamente desde el navegador
$publicPath = 'endpoints/uploads/';

if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_FILES['comprobante']) && $_FILES['comprobante']['error'] === UPLOAD_ERR_OK) {
            $nombreArchivo = $_FILES['comprobante']['name'];
            $archivoTemporal = $_FILES['comprobante']['tmp_name'];
            $tipoArchivo = $_FILES['comprobante']['type'];

            $tiposPermitidos = ['application/pdf'];
            if (!in_array($tipoArchivo, $tiposPermitidos)) {
                http_response_code(400);
                echo json_encode(['mensaje' => 'Error: Solo se permiten archivos PDF.']);
                exit;
            }

            // Nombre único para evitar duplicados
            $nombreArchivoUnico = uniqid('comprobante_') . '_' . $nombreArchivo;

            // Ruta física en el servidor
            $ubicacionFinal = $uploadDir . $nombreArchivoUnico;

            // Ruta accesible públicamente (lo que guardamos en DB)
            $rutaPublica = $publicPath . $nombreArchivoUnico;

            if (!move_uploaded_file($archivoTemporal, $ubicacionFinal)) {
                http_response_code(500);
                echo json_encode(['mensaje' => 'Error al mover el archivo.']);
                exit;
            }
        } else {
            http_response_code(400);
            echo json_encode(['mensaje' => 'Error: No se ha enviado ningún archivo o ha habido un error.']);
            exit;
        }

        // Datos adicionales
        $horas = isset($_POST['horas']) ? intval($_POST['horas']) : 0;
        $justificacion = isset($_POST['justificacion']) ? $_POST['justificacion'] : '';
        $comentario = isset($_POST['comentario']) ? $_POST['comentario'] : '';

        if (!is_numeric($horas) || $horas < 0) {
            http_response_code(400);
            echo json_encode(['mensaje' => 'Error: Las horas deben ser un número entero no negativo.']);
            exit;
        }

        $pdo = Conexion::getPDO();

        if (!isset($_SESSION['id_Usuario'])) {
            http_response_code(401);
            echo json_encode(['mensaje' => 'Error: Usuario no autenticado.']);
            exit;
        }

        $usuario_id = $_SESSION['id_Usuario'];

        // Guardar pago
        $stmt = $pdo->prepare("INSERT INTO PagoMensaul (id_Usuario, ComprobantPago, EstadoPago) VALUES (?, ?, ?)");
        $stmt->execute([$usuario_id, $rutaPublica, 'Pendiente']);
        $pago_id = $pdo->lastInsertId();

        // Guardar horas
        $semana = date("Y-m-d");
        $solicitudExoneracion = ""; 
        $pagoCompensativo = 0.0; 
        $estado = "Pendiente"; 

        $stmt = $pdo->prepare("INSERT INTO HorasTrabajo (id_Usuario, Semana, HorasRegistradas, MotivoFAltante, SolicitudExoneracion, PagoCompensativo, Estado) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$usuario_id, $semana, $horas, $justificacion, $solicitudExoneracion, $pagoCompensativo, $estado]);
        $horas_id = $pdo->lastInsertId();

        // Guardar comprobante
        $stmt = $pdo->prepare("INSERT INTO ComprobanteInicial (id_Usuario, id_Horas, id_Pago, Observaciones, Monto, EStadoAprovacion, FechaSalida) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$usuario_id, $horas_id, $pago_id, $comentario, 0, 'Pendiente', $semana]);

        http_response_code(200);
        echo json_encode(['mensaje' => 'Datos recibidos y procesados con éxito.']);

    } catch (PDOException $e) {
        http_response_code(500);
        error_log('Error al guardar en la base de datos: ' . $e->getMessage() . ' - ' . $e->getTraceAsString()); 
        echo json_encode(['mensaje' => 'Error al guardar en la base de datos.']);
    }
} else {
    http_response_code(405);
    echo json_encode(['mensaje' => 'Error: Método no permitido.']);
}
?>
