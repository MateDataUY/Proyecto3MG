<?php
// filepath: c:\Users\PCS\Desktop\Trabajos UTU\3MG\code\MATEDATA_2daEntrega\MATEDATA_2daEntrega\MATEDATA_6\endpoints\enviar_justificacion.php

session_start(); // Iniciar la sesión

require_once('../conexcion.php');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
        http_response_code(400);
        echo json_encode(['mensaje' => 'Error: JSON inválido.']);
        exit;
    }

    if (isset($data['justificacion'])) {
        $justificacion = $data['justificacion'];

        if (empty($justificacion)) {
            http_response_code(400);
            echo json_encode(['mensaje' => 'Error: La justificación no puede estar vacía.']);
            exit;
        }

        try {
            $pdo = Conexion::getPDO();

            // Obtener el ID del comprobante (deberías recibirlo desde el frontend o la sesión)
            $comprobante_id = isset($_SESSION['comprobante_id']) ? $_SESSION['comprobante_id'] : null; // Ejemplo usando sesión
            if ($comprobante_id === null) {
                // Si no tienes el ID del comprobante, puedes devolver un error o buscar una forma de obtenerlo
                http_response_code(400);
                echo json_encode(['mensaje' => 'Error: No se proporcionó el ID del comprobante.']);
                exit;
            }

            // Actualizar la justificación en la tabla ComprobanteInicial
            $stmt = $pdo->prepare("UPDATE ComprobanteInicial SET MotivoFAltante = ? WHERE id_Comprobante = ?");
            $stmt->execute([$justificacion, $comprobante_id]);

            http_response_code(200);
            echo json_encode(['mensaje' => 'Justificación recibida con éxito.']);
        } catch (PDOException $e) {
            http_response_code(500);
            error_log('Error al guardar la justificación en la base de datos: ' . $e->getMessage() . ' - ' . $e->getTraceAsString()); // Registrar el error en el log
            echo json_encode(['mensaje' => 'Error al guardar la justificación en la base de datos.']); // No mostrar detalles del error al cliente
        }

    } else {
        http_response_code(400);
        echo json_encode(['mensaje' => 'Error: No se recibió la justificación.']);
    }
} else {
    http_response_code(405);
    echo json_encode(['mensaje' => 'Error: Método no permitido.']);
}
?>