<?php

session_start(); // Iniciar la sesión

require_once('../conexcion.php');

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
        http_response_code(400);
        echo json_encode(['mensaje' => 'Error: JSON inválido.']);
        exit;
    }

    if (isset($data['horas'])) {
        $horas = $data['horas'];

        if (!is_numeric($horas) || $horas < 0 || !is_int($horas + 0)) {
            http_response_code(400);
            echo json_encode(['mensaje' => 'Error: Las horas deben ser un número entero no negativo.']);
            exit;
        }

        try {
            $pdo = Conexion::getPDO();

            // Obtener el ID del comprobante de la sesión
            $comprobante_id = isset($_SESSION['comprobante_id']) ? $_SESSION['comprobante_id'] : null;
            if ($comprobante_id === null) {
                http_response_code(400);
                echo json_encode(['mensaje' => 'Error: No se proporcionó el ID del comprobante en la sesión.']);
                exit;
            }

            // Actualizar las horas en la tabla ComprobanteInicial
            $stmt = $pdo->prepare("UPDATE ComprobanteInicial SET HorasRegistradas = ? WHERE id_Comprobante = ?");
            $stmt->execute([$horas, $comprobante_id]);

            http_response_code(200);
            echo json_encode(['mensaje' => 'Horas recibidas con éxito.', 'horas' => $horas]);
        } catch (PDOException $e) {
            http_response_code(500);
            error_log('Error al guardar las horas en la base de datos: ' . $e->getMessage() . ' - ' . $e->getTraceAsString()); // Registrar el error en el log
            echo json_encode(['mensaje' => 'Error al guardar las horas en la base de datos.']); // No mostrar detalles del error al cliente
        }

    } else {
        http_response_code(400);
        echo json_encode(['mensaje' => 'Error: No se recibieron las horas.']);
    }
} else {
    http_response_code(405);
    echo json_encode(['mensaje' => 'Error: Método no permitido.']);
}
?>