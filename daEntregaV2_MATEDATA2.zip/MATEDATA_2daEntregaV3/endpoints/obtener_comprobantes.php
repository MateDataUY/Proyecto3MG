<?php
// filepath: c:\Users\PCS\Desktop\Trabajos UTU\3MG\code\MATEDATA_2daEntrega\MATEDATA_2daEntrega\MATEDATA_6\endpoints\obtener_comprobantes.php

// obtener_comprobantes.php
require_once('../conexcion.php');

header('Content-Type: application/json');

try {
    $pdo = Conexion::getPDO();
    $stmt = $pdo->prepare("SELECT id_Comprobante, id_Usuario FROM ComprobanteInicial WHERE Estado = 'Pendiente'");
    $stmt->execute();
    $comprobantes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($comprobantes);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['mensaje' => 'Error al obtener los comprobantes: ' . $e->getMessage()]);
}
?>