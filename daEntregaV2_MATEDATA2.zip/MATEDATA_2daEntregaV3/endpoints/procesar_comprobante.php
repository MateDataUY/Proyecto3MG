<?php
// filepath: c:\Users\PCS\Desktop\Trabajos UTU\3MG\code\MATEDATA_2daEntrega\MATEDATA_2daEntrega\MATEDATA_6\endpoints\procesar_comprobante.php

require_once('../conexcion.php');

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (!isset($data['id_Comprobante']) || !isset($data['accion'])) {
        http_response_code(400);
        echo json_encode(['mensaje' => 'Error: No se proporcionó el ID del comprobante o la acción.']);
        exit;
    }

    $idComprobante = $data['id_Comprobante'];
    $accion = $data['accion'];

    if ($accion !== 'aceptar' && $accion !== 'rechazar') {
        http_response_code(400);
        echo json_encode(['mensaje' => 'Error: Acción no válida.']);
        exit;
    }

    $estado = ($accion === 'aceptar') ? 'Aprobado' : 'Rechazado';

    try {
        $pdo = Conexion::getPDO();
        $stmt = $pdo->prepare("UPDATE ComprobanteInicial SET EStadoAprovacion = ? WHERE id_Comprobante = ?");
        $stmt->execute([$estado, $idComprobante]);

        echo json_encode(['mensaje' => 'Comprobante ' . $estado . ' con éxito.']);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['mensaje' => 'Error al procesar el comprobante: ' . $e->getMessage()]);
    }
} else {
    http_response_code(405);
    echo json_encode(['mensaje' => 'Error: Método no permitido.']);
}
?>