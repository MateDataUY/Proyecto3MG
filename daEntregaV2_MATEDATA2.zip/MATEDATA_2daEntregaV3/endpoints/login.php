<?php
session_start();
require_once('../conexcion.php');

header('Content-Type: application/json; charset=utf-8');

try {
    $pdo = Conexion::getPDO();

    // Leer JSON del body
    $data = json_decode(file_get_contents("php://input"), true);
    $ci = $data['CI'] ?? '';
    $contrasena = $data['Contrasena'] ?? '';

    // Buscar usuario
    $stmt = $pdo->prepare("SELECT id_Usuario, Contrasena FROM Usuario WHERE CI = ?");
    $stmt->execute([$ci]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($usuario && password_verify($contrasena, $usuario['Contrasena'])) {
        // Guardar en sesión
        $_SESSION['id_Usuario'] = $usuario['id_Usuario'];
        session_regenerate_id(true); // Seguridad

        echo json_encode([
            "success" => true,
            "mensaje" => "Login correcto"
        ]);
    } else {
        echo json_encode([
            "success" => false,
            "mensaje" => "CI o contraseña incorrectos"
        ]);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "mensaje" => "Error en el servidor"]);
    error_log("Error login.php: " . $e->getMessage());
}
