<?php
require_once __DIR__ . '/../conexcion.php';

class Usuario {
    private $pdo;

    public function __construct() {
        $this->pdo = Conexion::getPDO();
    }

    public function login($CI, $Contrasena) {
        $stmt = $this->pdo->prepare("SELECT id_Usuario, Contrasena, Estado FROM Usuario WHERE CI = :ci");
        $stmt->execute(['ci' => $CI]);
        $usuario = $stmt->fetch();

        if (!$usuario) {
            return ['success' => false, 'mensaje' => 'Usuario no encontrado'];
        }
        if (!array_key_exists('Estado', $usuario)) {
            return ['success' => false, 'mensaje' => 'No se encontró el estado de la cuenta'];
        }
        if ($usuario['Estado'] !== 'Activo') {
            return ['success' => false, 'mensaje' => 'La cuenta está en estado: ' . $usuario['Estado']];
        }
        if (!isset($usuario['Contrasena'])) {
            return ['success' => false, 'mensaje' => 'Contraseña no encontrada en BD'];
        }
        if (!password_verify($Contrasena, $usuario['Contrasena'])) {
            return ['success' => false, 'mensaje' => 'Contraseña incorrecta'];
        }
        return [
            'success' => true,
            'usuario_id' => $usuario['id_Usuario'],
            'mensaje' => 'Inicio de sesión exitoso'
        ];
    }

    public function registrar($data) {
        $stmt = $this->pdo->prepare(
            "INSERT INTO Usuario (Nombre, Apellido, Direccion, CI, Email, Contrasena, FechaRegistro, Estado)
             VALUES (:nombre, :apellido, :direccion, :ci, :email, :contrasena, NOW(), 'Pendiente')"
        );

        try {
            $stmt->execute([
                'nombre' => $data['Nombre'],
                'apellido' => $data['Apellido'],
                'direccion' => $data['Direccion'],
                'ci' => $data['CI'],
                'email' => $data['Email'],
                'contrasena' => $hashedPassword = password_hash($data['Contrasena'], PASSWORD_DEFAULT)
            ]);

            $usuarioId = $this->pdo->lastInsertId();


            $stmtTel = $this->pdo->prepare(
                "INSERT INTO Telefonousuario (id_usuario, telefono) VALUES (:id_usuario, :telefono)"
            );
            $stmtTel->execute([
                'id_usuario' => $usuarioId,
                'telefono' => $data['Telefono']
            ]);

            return ['success' => true, 'mensaje' => 'Usuario registrado'];
        } catch (PDOException $e) {
            return ['success' => false, 'mensaje' => $e->getMessage()];
        }
    }
}
?>