
<?php
require_once __DIR__ . '/../conexcion.php';

class Admin {
    private $pdo;

    public function __construct() {
        $this->pdo = Conexion::getPDO();
    }

    public function login($Nombre, $Contrasena) {
        $stmt = $this->pdo->prepare("SELECT id_Admin, Contrasena FROM Admin WHERE Nombre = :nombre");
        $stmt->execute(['nombre' => $Nombre]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($Contrasena, $admin['Contrasena'])) {
            return ['success' => true, 'admin_id' => $admin['id_Admin']];
        }

        return ['success' => false, 'mensaje' => 'Credenciales inválidas'];
    }
}
?>